"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_error";
exports.ids = ["pages/_error"];
exports.modules = {

/***/ "./pages/_error.jsx":
/*!**************************!*\
  !*** ./pages/_error.jsx ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction Error({ statusCode  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n        children: statusCode ? `An error ${statusCode} occurred on server` : \"An error occurred on client\"\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\MCI-ACHMAD\\\\Desktop\\\\E-services\\\\frontend\\\\pages\\\\_error.jsx\",\n        lineNumber: 3,\n        columnNumber: 9\n    }, this);\n}\nError.getInitialProps = ({ res , err  })=>{\n    const statusCode = res ? res.statusCode : err ? err.statusCode : 404;\n    return {\n        statusCode\n    };\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Error);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fZXJyb3IuanN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQUEsU0FBU0EsS0FBSyxDQUFDLEVBQUVDLFVBQVUsR0FBRSxFQUFFO0lBQzNCLHFCQUNJLDhEQUFDQyxHQUFDO2tCQUNHRCxVQUFVLEdBQ0wsQ0FBQyxTQUFTLEVBQUVBLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxHQUMzQyw2QkFBNkI7Ozs7O1lBQ25DLENBQ1A7Q0FDSjtBQUVERCxLQUFLLENBQUNHLGVBQWUsR0FBRyxDQUFDLEVBQUVDLEdBQUcsR0FBRUMsR0FBRyxHQUFFLEdBQUs7SUFDdEMsTUFBTUosVUFBVSxHQUFHRyxHQUFHLEdBQUdBLEdBQUcsQ0FBQ0gsVUFBVSxHQUFHSSxHQUFHLEdBQUdBLEdBQUcsQ0FBQ0osVUFBVSxHQUFHLEdBQUc7SUFDcEUsT0FBTztRQUFFQSxVQUFVO0tBQUU7Q0FDeEI7QUFFRCxpRUFBZUQsS0FBSyIsInNvdXJjZXMiOlsid2VicGFjazovL2Zyb250ZW5kLy4vcGFnZXMvX2Vycm9yLmpzeD8zMjM2Il0sInNvdXJjZXNDb250ZW50IjpbImZ1bmN0aW9uIEVycm9yKHsgc3RhdHVzQ29kZSB9KSB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPHA+XG4gICAgICAgICAgICB7c3RhdHVzQ29kZVxuICAgICAgICAgICAgICAgID8gYEFuIGVycm9yICR7c3RhdHVzQ29kZX0gb2NjdXJyZWQgb24gc2VydmVyYFxuICAgICAgICAgICAgICAgIDogJ0FuIGVycm9yIG9jY3VycmVkIG9uIGNsaWVudCd9XG4gICAgICAgIDwvcD5cbiAgICApXG59XG5cbkVycm9yLmdldEluaXRpYWxQcm9wcyA9ICh7IHJlcywgZXJyIH0pID0+IHtcbiAgICBjb25zdCBzdGF0dXNDb2RlID0gcmVzID8gcmVzLnN0YXR1c0NvZGUgOiBlcnIgPyBlcnIuc3RhdHVzQ29kZSA6IDQwNFxuICAgIHJldHVybiB7IHN0YXR1c0NvZGUgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBFcnJvclxuIl0sIm5hbWVzIjpbIkVycm9yIiwic3RhdHVzQ29kZSIsInAiLCJnZXRJbml0aWFsUHJvcHMiLCJyZXMiLCJlcnIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_error.jsx\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_error.jsx"));
module.exports = __webpack_exports__;

})();