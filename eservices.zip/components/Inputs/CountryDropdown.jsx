export default function Countrydropdown() {
    return (
        <select className="leading-tight text-gray-500 border-0 focus:outline-none">
            <option>Singapore</option>
            <option>Indonesia</option>
        </select>
    )
}
