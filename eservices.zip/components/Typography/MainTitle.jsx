export default function Maintitle({ title }) {
    return <div className="py-2 text-2xl font-bold text-gray-700">{title}</div>
}
