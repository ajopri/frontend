import Mainlayout from '@/components/Layouts/MainLayout'

export default function Dashboard() {
    return (
        <Mainlayout pageTitle="admin dashboard">
            <div>Admin Dashboard</div>
        </Mainlayout>
    )
}
