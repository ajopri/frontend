export default function middleware(req) {
    console.log(req.headers)
}
